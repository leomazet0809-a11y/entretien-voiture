/* Configuration Firebase du projet « Entretien voiture ».
   À remplir avec l'objet firebaseConfig donné par la console Firebase :
   Paramètres du projet → Général → Vos applications → Application Web.
   Ces valeurs ne sont pas secrètes : la protection des données repose sur la connexion
   et sur les règles de sécurité de Firestore. */
(function (EV) {
  'use strict';

  EV.firebaseConfig = {
    apiKey: 'A_REMPLIR',
    authDomain: 'entretien-voiture-67366.firebaseapp.com',
    projectId: 'entretien-voiture-67366',
    storageBucket: 'A_REMPLIR',
    messagingSenderId: 'A_REMPLIR',
    appId: 'A_REMPLIR'
  };
})(window.EV = window.EV || {});
